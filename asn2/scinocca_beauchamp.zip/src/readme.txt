SENG474 Programming Assignment 2

Stephen Scinocca
Austin Beauchamp


Usage (with both data files in working directory):

$ python Q1.py
$ python Q2.py
$ python Q3.py
